ANIME ADVENTURES MACRO
======================
1. Keep this whole folder together (do not move AnimeAdventures.exe out on its own).
2. Double-click AnimeAdventures.exe to run.
3. Premium only: enter your license key when asked (get one in the Discord).
4. On first start it asks for your Roblox display name (used to read your damage).

Open Anime Adventures in Roblox before starting the macro.